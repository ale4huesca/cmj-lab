# CMJ Lab (Android)

App para medir saltos CMJ grabando a cámara lenta (120/240 fps si el móvil lo permite a las apps).

- **Descargar la app:** pestaña **Releases** (a la derecha) → `CMJLab.apk`.
- Cada vez que se sube un cambio, GitHub compila la app solo (pestaña **Actions**).

Si la pestaña Actions no muestra nada, crea el archivo `.github/workflows/build.yml`
(Add file → Create new file) y pega el contenido de `copia-build.yml`.
