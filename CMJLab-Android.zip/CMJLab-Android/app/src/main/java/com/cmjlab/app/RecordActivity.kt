package com.cmjlab.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Range
import android.util.Size
import android.util.TypedValue
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

/**
 * Grabación de saltos con la cámara trasera al máximo de fps que el móvil
 * permite a las apps (sesión Camera2 de alta velocidad: 120/240/480 fps).
 * Si el fabricante no lo permite, usa el máximo normal (normalmente 60 fps).
 */
class RecordActivity : ComponentActivity(), SurfaceHolder.Callback {

    companion object {
        const val EXTRA_FILE = "file"
        const val EXTRA_FPS = "fps"
        private const val PREFS = "cmj"
        private const val KEY_MODE = "mode"
        private const val AUTO_SECONDS = 4
    }

    data class Mode(
        val cameraId: String,
        val size: Size,
        val fps: Int,
        val highSpeed: Boolean,
        val previewRange: Range<Int>,
        val recordRange: Range<Int>,
        val orientation: Int
    ) {
        val key get() = "$cameraId-${size.width}x${size.height}-$fps-$highSpeed"
        val label get() = "$fps fps · ${size.width}×${size.height}" + if (highSpeed) " · cámara lenta" else " · normal"
    }

    /** Contenedor que mantiene la proporción de la imagen de la cámara. */
    class AspectFrame(ctx: Context) : FrameLayout(ctx) {
        var ratio = 9f / 16f // ancho / alto
            set(v) { field = v; requestLayout() }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = MeasureSpec.getSize(widthMeasureSpec)
            val h = MeasureSpec.getSize(heightMeasureSpec)
            var cw = w
            var ch = (w / ratio).toInt()
            if (h in 1 until ch) { ch = h; cw = (h * ratio).toInt() }
            super.onMeasure(
                MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
            )
        }
    }

    private val manager by lazy { getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    private val ui = Handler(Looper.getMainLooper())
    private var camThread: HandlerThread? = null
    private var camHandler: Handler? = null

    private lateinit var surfaceView: SurfaceView
    private lateinit var box: AspectFrame
    private lateinit var info: TextView
    private lateinit var timer: TextView
    private lateinit var countdown: TextView
    private lateinit var recBtn: Button
    private lateinit var modeBtn: Button
    private lateinit var autoBtn: Button

    @Volatile private var device: CameraDevice? = null
    @Volatile private var session: CameraCaptureSession? = null
    @Volatile private var recorder: MediaRecorder? = null
    @Volatile private var opening = false
    @Volatile private var recording = false
    private var outFile: File? = null
    private var modes: List<Mode> = emptyList()
    private var modeIdx = 0
    private var surfaceReady = false
    private var askingPermission = false
    private var autoRunning = false
    private var recStart = 0L

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            askingPermission = false
            if (ok) startCamera() else {
                toast("Sin permiso de cámara no se puede grabar")
                finish()
            }
        }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun pill(text: String, bg: Int, fg: Int = Color.WHITE): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(fg)
        textSize = 15f
        background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(bg) }
        setPadding(dp(14), dp(10), dp(14), dp(10))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        box = AspectFrame(this)
        surfaceView = SurfaceView(this)
        box.addView(surfaceView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(36), dp(12), 0)
        }
        info = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0x99000000.toInt()) }
            setPadding(dp(12), dp(8), dp(12), dp(8))
            text = "Preparando cámara…"
        }
        timer = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(0xFFFF4D4D.toInt()) }
            setPadding(dp(10), dp(4), dp(10), dp(4))
            visibility = View.GONE
        }
        top.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        top.addView(timer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        root.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val close = pill("✕", 0x99000000.toInt())
        close.setOnClickListener { finish() }
        root.addView(close, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP or Gravity.END).apply { topMargin = dp(36); rightMargin = dp(12) })

        countdown = TextView(this).apply {
            setTextColor(0xFFC8F25A.toInt()); textSize = 110f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setShadowLayer(20f, 0f, 0f, Color.BLACK)
        }
        root.addView(countdown, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(36))
        }
        modeBtn = pill("Modo", 0xCC1D232C.toInt())
        recBtn = pill("● GRABAR", 0xFFFF4D4D.toInt()).apply { textSize = 18f; setTypeface(typeface, Typeface.BOLD) }
        autoBtn = pill("⏱ 3 s + ${AUTO_SECONDS} s", 0xCC1D232C.toInt())
        val lp = { w: Float -> LinearLayout.LayoutParams(0, dp(64), w).apply { marginStart = dp(5); marginEnd = dp(5) } }
        bar.addView(modeBtn, lp(1f))
        bar.addView(recBtn, lp(1.4f))
        bar.addView(autoBtn, lp(1.1f))
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        recBtn.isEnabled = false
        autoBtn.isEnabled = false
        recBtn.setOnClickListener { if (recording) stopRecording() else startRecording() }
        autoBtn.setOnClickListener { runAuto() }
        modeBtn.setOnClickListener { chooseMode() }

        setContentView(root)
        surfaceView.holder.addCallback(this)
    }

    // ------------------------------------------------------------ ciclo de vida

    override fun onResume() {
        super.onResume()
        startThread()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else if (!askingPermission) {
            askingPermission = true
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onPause() {
        ui.removeCallbacksAndMessages(null)
        autoRunning = false
        countdown.text = ""
        if (recording) {
            recording = false
            try { recorder?.stop() } catch (_: Exception) {}
            outFile?.delete()
            onRecordingUi(false)
        }
        closeCamera()
        stopThread()
        super.onPause()
    }

    private fun startThread() {
        if (camThread != null) return
        camThread = HandlerThread("camara").also { it.start() }
        camHandler = Handler(camThread!!.looper)
    }

    private fun stopThread() {
        camThread?.quitSafely()
        try { camThread?.join(500) } catch (_: InterruptedException) {}
        camThread = null
        camHandler = null
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (modes.isEmpty()) return
        val m = modes[modeIdx]
        if (width == m.size.width && height == m.size.height) openCamera()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        closeCamera()
    }

    // ------------------------------------------------------------ modos de cámara

    private fun findModes(): List<Mode> {
        val out = mutableListOf<Mode>()
        val ids = try { manager.cameraIdList } catch (e: Exception) { emptyArray<String>() }
        for (id in ids) {
            val ch = try { manager.getCameraCharacteristics(id) } catch (e: Exception) { continue }
            if (ch.get(CameraCharacteristics.LENS_FACING) != CameraMetadata.LENS_FACING_BACK) continue
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: continue
            val orient = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)

            // Alta velocidad (cámara lenta) disponible para apps
            if (caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO)) {
                val hsSizes = try { map.highSpeedVideoSizes } catch (e: Exception) { emptyArray<Size>() }
                for (size in hsSizes) {
                    val ranges = try { map.getHighSpeedVideoFpsRangesFor(size) } catch (e: Exception) { continue }
                    for (r in ranges.filter { it.lower == it.upper && it.upper >= 60 }) {
                        val fps = r.upper
                        val prev = ranges.filter { it.upper == fps && it.lower < fps }.minByOrNull { it.lower } ?: r
                        out.add(Mode(id, size, fps, true, prev, r, orient))
                    }
                }
            }

            // Modo normal (respaldo): máximo de fps fijos del sensor
            val ae = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: emptyArray()
            val best = ae.filter { it.lower == it.upper }.maxByOrNull { it.upper } ?: ae.maxByOrNull { it.upper }
            val sizes = map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray()
            val sz = sizes.firstOrNull { it.width == 1920 && it.height == 1080 }
                ?: sizes.firstOrNull { it.width == 1280 && it.height == 720 }
                ?: sizes.maxByOrNull { it.width * it.height }
            if (best != null && sz != null) out.add(Mode(id, sz, best.upper, false, best, best, orient))
        }
        return out
            .distinctBy { "${it.fps}-${it.size.width}x${it.size.height}-${it.highSpeed}" }
            .sortedWith(compareByDescending<Mode> { it.fps }.thenByDescending { it.size.width * it.size.height })
    }

    private fun startCamera() {
        if (modes.isEmpty()) {
            modes = findModes()
            if (modes.isEmpty()) {
                info.text = "No se ha encontrado una cámara trasera compatible"
                return
            }
            val saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_MODE, null)
            modeIdx = modes.indexOfFirst { it.key == saved }.takeIf { it >= 0 } ?: 0
        }
        prepareSurface()
    }

    private fun describe(m: Mode): String {
        val maxHs = modes.filter { it.highSpeed }.maxOfOrNull { it.fps }
        return when {
            m.highSpeed -> "${m.fps} fps · ${m.size.width}×${m.size.height} · cámara lenta ✔"
            maxHs == null -> "${m.fps} fps · ${m.size.width}×${m.size.height}\nTu móvil no deja usar la cámara lenta a otras apps"
            else -> "${m.fps} fps · ${m.size.width}×${m.size.height} · normal"
        }
    }

    private fun prepareSurface() {
        if (modes.isEmpty()) return
        val m = modes[modeIdx]
        box.ratio = m.size.height.toFloat() / m.size.width.toFloat() // vertical
        info.text = describe(m)
        modeBtn.text = "${m.fps} fps ▾"
        surfaceView.holder.setFixedSize(m.size.width, m.size.height)
        if (surfaceReady) {
            val f = surfaceView.holder.surfaceFrame
            if (f.width() == m.size.width && f.height() == m.size.height) openCamera()
        }
    }

    private fun chooseMode() {
        if (recording || modes.isEmpty()) return
        val labels = modes.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Modo de grabación")
            .setSingleChoiceItems(labels, modeIdx) { d, which ->
                d.dismiss()
                if (which != modeIdx) {
                    modeIdx = which
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MODE, modes[which].key).apply()
                    closeCamera()
                    prepareSurface()
                }
            }
            .show()
    }

    private fun modeFailed(reason: String) {
        ui.post {
            if (modes.isEmpty()) return@post
            val bad = modes[modeIdx]
            closeCamera()
            modes = modes.filterIndexed { i, _ -> i != modeIdx }
            if (modes.isEmpty()) {
                info.text = "No se pudo iniciar la grabación ($reason)"
                return@post
            }
            if (modeIdx >= modes.size) modeIdx = 0
            toast("${bad.label} no disponible ($reason). Probando ${modes[modeIdx].fps} fps…")
            prepareSurface()
        }
    }

    // ------------------------------------------------------------ Camera2

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        if (device != null || opening || !surfaceReady || modes.isEmpty()) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val h = camHandler ?: return
        val m = modes[modeIdx]
        opening = true
        try {
            manager.openCamera(m.cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    opening = false
                    device = d
                    createSession()
                }

                override fun onDisconnected(d: CameraDevice) {
                    opening = false
                    d.close()
                    if (device == d) device = null
                }

                override fun onError(d: CameraDevice, error: Int) {
                    opening = false
                    d.close()
                    if (device == d) device = null
                    ui.post { info.text = "Error de cámara ($error). Cierra otras apps de cámara y vuelve a intentarlo." }
                }
            }, h)
        } catch (e: Exception) {
            opening = false
            info.text = "No se pudo abrir la cámara: ${e.message}"
        }
    }

    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun bitrate(m: Mode): Int {
        val bits = m.size.width.toLong() * m.size.height.toLong() * m.fps.toLong() * 12L / 100L
        return bits.coerceIn(8_000_000L, 80_000_000L).toInt()
    }

    private fun createSession() {
        val d = device ?: return
        val m = modes[modeIdx]
        val dir = File(filesDir, "videos").apply { mkdirs() }
        val file = File(dir, "cmj_${System.currentTimeMillis()}.mp4")
        val rec = newRecorder()
        try {
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setOutputFile(file.absolutePath)
            rec.setVideoEncodingBitRate(bitrate(m))
            rec.setVideoFrameRate(m.fps)
            rec.setVideoSize(m.size.width, m.size.height)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setOrientationHint(m.orientation)
            rec.prepare()
        } catch (e: Exception) {
            rec.release()
            file.delete()
            modeFailed("el codificador no lo admite")
            return
        }
        recorder = rec
        outFile = file

        val targets = listOf(surfaceView.holder.surface, rec.surface)
        val cb = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                startPreview()
            }

            override fun onConfigureFailed(s: CameraCaptureSession) {
                modeFailed("la cámara no acepta este modo")
            }
        }
        try {
            if (m.highSpeed) d.createConstrainedHighSpeedCaptureSession(targets, cb, camHandler)
            else d.createCaptureSession(targets, cb, camHandler)
        } catch (e: Exception) {
            modeFailed(e.message ?: "error")
        }
    }

    private fun repeatReq(s: CameraCaptureSession, req: CaptureRequest) {
        if (s is CameraConstrainedHighSpeedCaptureSession) {
            s.setRepeatingBurst(s.createHighSpeedRequestList(req), null, camHandler)
        } else {
            s.setRepeatingRequest(req, null, camHandler)
        }
    }

    private fun startPreview() {
        val d = device ?: return
        val s = session ?: return
        val m = modes[modeIdx]
        try {
            val template = if (m.highSpeed) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW
            val req = d.createCaptureRequest(template).apply {
                addTarget(surfaceView.holder.surface)
                set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, m.previewRange)
            }.build()
            repeatReq(s, req)
            ui.post {
                recBtn.isEnabled = true
                autoBtn.isEnabled = true
            }
        } catch (e: Exception) {
            modeFailed(e.message ?: "error")
        }
    }

    private fun startRecording() {
        if (recording) return
        val h = camHandler ?: return
        recBtn.isEnabled = false
        modeBtn.isEnabled = false
        h.post {
            val d = device
            val s = session
            val rec = recorder
            if (d == null || s == null || rec == null) {
                ui.post { recBtn.isEnabled = true; modeBtn.isEnabled = true }
                return@post
            }
            val m = modes[modeIdx]
            try {
                rec.start()
                val req = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                    addTarget(surfaceView.holder.surface)
                    addTarget(rec.surface)
                    set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, m.recordRange)
                }.build()
                repeatReq(s, req)
                recording = true
                recStart = SystemClock.elapsedRealtime()
                ui.post { onRecordingUi(true) }
            } catch (e: Exception) {
                ui.post {
                    toast("No se pudo grabar: ${e.message}")
                    recBtn.isEnabled = true
                    modeBtn.isEnabled = true
                }
            }
        }
    }

    private fun stopRecording() {
        if (!recording) return
        val elapsed = SystemClock.elapsedRealtime() - recStart
        if (elapsed < 1000) { // mínimo 1 s para que el archivo sea válido
            ui.postDelayed({ stopRecording() }, 1000 - elapsed)
            return
        }
        recording = false
        recBtn.isEnabled = false
        val h = camHandler ?: return
        h.post {
            try { session?.stopRepeating() } catch (_: Exception) {}
            var ok = true
            try { recorder?.stop() } catch (_: Exception) { ok = false }
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            val f = outFile
            val fps = modes.getOrNull(modeIdx)?.fps ?: 0
            ui.post {
                onRecordingUi(false)
                if (ok && f != null && f.exists() && f.length() > 0) {
                    setResult(RESULT_OK, Intent().putExtra(EXTRA_FILE, f.name).putExtra(EXTRA_FPS, fps))
                    finish()
                } else {
                    f?.delete()
                    toast("La grabación ha fallado, vuelve a intentarlo")
                    closeCamera()
                    prepareSurface()
                }
            }
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (_: Exception) {}
        session = null
        try { device?.close() } catch (_: Exception) {}
        device = null
        opening = false
        if (!recording) {
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            outFile?.let { if (it.exists() && it.length() == 0L) it.delete() }
        }
        recBtn.isEnabled = false
        autoBtn.isEnabled = false
    }

    // ------------------------------------------------------------ grabación: UI

    private val tick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000.0
            timer.text = String.format(Locale.US, "● REC %.1f s", s)
            ui.postDelayed(this, 100)
        }
    }

    private fun onRecordingUi(on: Boolean) {
        if (on) {
            timer.visibility = View.VISIBLE
            recBtn.text = "■ PARAR"
            recBtn.isEnabled = true
            autoBtn.isEnabled = false
            ui.post(tick)
        } else {
            timer.visibility = View.GONE
            recBtn.text = "● GRABAR"
            modeBtn.isEnabled = true
        }
    }

    private fun runAuto() {
        if (autoRunning || recording || device == null) return
        autoRunning = true
        autoBtn.isEnabled = false
        listOf("3", "2", "1").forEachIndexed { i, s -> ui.postDelayed({ countdown.text = s }, i * 1000L) }
        ui.postDelayed({ countdown.text = "¡YA!"; startRecording() }, 3000)
        ui.postDelayed({ countdown.text = "" }, 3700)
        ui.postDelayed({ autoRunning = false; stopRecording() }, 3000L + AUTO_SECONDS * 1000L)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
