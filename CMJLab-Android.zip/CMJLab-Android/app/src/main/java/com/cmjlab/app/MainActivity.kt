package com.cmjlab.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * Pantalla principal: muestra la app CMJ Lab (assets/index.html) en un WebView
 * y le da acceso a la grabación nativa a alta velocidad (RecordActivity).
 */
class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var pageLoaded = false
    private var pendingJs: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val videosDir by lazy { File(filesDir, "videos").apply { mkdirs() } }

    // Selector de vídeos de la galería (para <input type="file">)
    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        fileCallback = null
    }

    // Resultado de la grabación nativa
    private val recordLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                val name = data.getStringExtra(RecordActivity.EXTRA_FILE)
                val fps = data.getIntExtra(RecordActivity.EXTRA_FPS, 0)
                if (name != null) {
                    val url = "https://appassets.androidplatform.net/videos/$name"
                    runJs("window.onNativeVideo && window.onNativeVideo('$url', $fps)")
                }
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cleanupOldVideos()

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/videos/", WebViewAssetLoader.InternalStoragePathHandler(this, videosDir))
            .build()

        web = WebView(this)
        web.setBackgroundColor(0xFF0D1014.toInt())
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return loader.shouldInterceptRequest(u)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageLoaded = true
                pendingJs?.let { web.evaluateJavascript(it, null) }
                pendingJs = null
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (callback == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    pickVideo.launch("video/*")
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "AndroidCam")
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun runJs(js: String) {
        if (pageLoaded) web.evaluateJavascript(js, null) else pendingJs = js
    }

    /** Funciones que la página puede llamar como window.AndroidCam.xxx() */
    inner class Bridge {
        @JavascriptInterface
        fun record() {
            runOnUiThread { recordLauncher.launch(Intent(this@MainActivity, RecordActivity::class.java)) }
        }

        @JavascriptInterface
        fun saveText(name: String, text: String) {
            runOnUiThread { saveToDownloads(name.substringAfterLast('/'), "text/csv", text.toByteArray()) }
        }

        @JavascriptInterface
        fun saveVideo(url: String) {
            runOnUiThread { saveVideoToGallery(url.substringAfterLast('/')) }
        }
    }

    private fun saveToDownloads(name: String, mime: String, bytes: ByteArray) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("insert")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            toast("Guardado en Descargas: $name")
        } catch (e: Exception) {
            toast("No se pudo guardar el archivo")
        }
    }

    private fun saveVideoToGallery(name: String) {
        val src = File(videosDir, name)
        if (!src.exists()) {
            toast("Vídeo no encontrado"); return
        }
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/CMJ Lab")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("insert")
            contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            toast("Vídeo guardado en la galería (Películas/CMJ Lab)")
        } catch (e: Exception) {
            toast("No se pudo guardar el vídeo")
        }
    }

    /** Conserva solo los 5 vídeos más recientes en el almacenamiento interno. */
    private fun cleanupOldVideos() {
        val files = videosDir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        files.drop(5).forEach { it.delete() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
